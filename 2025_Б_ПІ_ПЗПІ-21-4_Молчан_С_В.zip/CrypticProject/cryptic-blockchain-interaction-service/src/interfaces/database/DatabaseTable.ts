// src/interfaces/DatabaseTable.ts
export interface IDatabaseTable {

  }
  