import { Given, When, Then, After, Before } from '@cucumber/cucumber';
import { expect } from 'chai';
import sinon from 'sinon';
import axios from 'axios';
import { walletService } from '../../services/walletService';
import { ServerUnaryCall, sendUnaryData } from '@grpc/grpc-js';

// Змінні контексту
let portfolioId: string;
let addresses: string[];
let grpcResponse: any;
let grpcError: Error | null = null;

// Створюємо мок для axios для симуляції зовнішніх API-викликів
let axiosGetStub: sinon.SinonStub;

// Перед кожним тестом – підготовка моку
Before(() => {
  axiosGetStub = sinon.stub(axios, 'get');
});

// Після кожного тесту – відновлення моку
After(() => {
  axiosGetStub.restore();
});

Given('гаманець з portfolioId {string} і адресами {string}', function (pId: string, addrStr: string) {
  portfolioId = pId;
  addresses = addrStr.split(',').map(addr => addr.trim());
});

When('я запитую інформацію про монети', async function () {
  // Налаштування симуляції відповідей від зовнішніх сервісів:
  // Наприклад, при запиті балансу для адреси – повертаємо симульовану відповідь.
  axiosGetStub.callsFake(async (url: string, config: any) => {
    if (url.includes('/balance')) {
      return { data: { balance: '1000000000000000000' } }; // 1 ETH (wei)
    } else if (url.includes('/erc20')) {
      return { data: [] }; // Порожній масив токенів
    } else if (url.includes('cryptocompare.com/data/price')) {
      return { data: { USD: 2000 } }; // Поточна ціна ETH
    } else if (url.includes('cryptocompare.com/data/v2/histoday')) {
      return { data: { Data: { Data: [{ close: 1900 }] } } }; // Історична ціна ETH 1 годину тому
    } else if (url.includes('/transfers')) {
      // Якщо тестуємо метод getAveragePurchasePrice, можна повернути приклад даних
      return { data: { result: [] } };
    }
    return { data: {} };
  });

  // Створення фіктивного gRPC виклику
  const call = {
    request: {
      portfolioId,
      address: addresses,
    }
  } as unknown as ServerUnaryCall<any, any>;

  // Виклик методу
  await walletService.GetWalletCoins(call, (error, response) => {
    grpcError = error as Error | null; // або просто зберігайте error без приведення
    grpcResponse = response;
  });
});

Then('я повинен отримати список монет з загальним значенням портфеля в USDT', function () {
  expect(grpcError).to.be.null;
  expect(grpcResponse).to.have.property('coins');
  expect(grpcResponse.coins).to.be.an('array');
  expect(grpcResponse).to.have.property('totalPortfolioValueUSDT');

  // Приклад перевірки для ETH (враховуючи, що 1 ETH * 2000 USD = 2000)
  const ethCoin = grpcResponse.coins.find((coin: any) => coin.symbol === 'ETH');
  expect(ethCoin).to.exist;
  expect(ethCoin.balance).to.equal('1.0'); // formatEther("1000000000000000000") має повернути 1.0
  expect(ethCoin.currentMarketPrice).to.equal('2000');
  expect(grpcResponse.totalPortfolioValueUSDT).to.equal('2000');
});
