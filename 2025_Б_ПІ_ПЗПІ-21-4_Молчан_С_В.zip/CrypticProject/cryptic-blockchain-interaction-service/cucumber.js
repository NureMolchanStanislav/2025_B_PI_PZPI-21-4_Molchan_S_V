module.exports = {
  default: {
    require: ['src/features/**/*.ts'],
    format: ['progress-bar'],
    parallel: 1
  }
}
