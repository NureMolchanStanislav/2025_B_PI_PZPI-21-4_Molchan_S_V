using Cryptic_Domain.Database.Config.Interfaces;
using Cryptic_Domain.Database.Interfaces;
using Cryptic_Domain.Services;
using GatewayService.Interfaces.Config;
using GatewayService.Interfaces.Services;
using GatewayService.Services;
using GatewayService.Services.Config;

namespace GatewayService.DI;

public static class ConfigurationDIConfigure
{
    public static void InjectConfiguration(this IServiceCollection services, ConfigService config)
    {
        services.AddSingleton<IDatabaseConfiguration>(config);
        services.AddSingleton<IDatabaseConnectionService, DatabaseConnectionService>();
    }

    public static void ConfigureJwtConfiguration (this IServiceCollection services)
    {
        services.AddSingleton<IJwtConfiguration,  JwtConfiguration>();
    }

    public static void ConfigrePasswordResetService(this IServiceCollection services)
    {
        services.AddMemoryCache();
        services.AddSingleton<IEmailConfiguration, EmailConfiguration>();
        services.AddSingleton<IPasswordResetCodeService, PasswordResetCodeService>();
        services.AddSingleton<IEmailService, EmailService>();
    }
}