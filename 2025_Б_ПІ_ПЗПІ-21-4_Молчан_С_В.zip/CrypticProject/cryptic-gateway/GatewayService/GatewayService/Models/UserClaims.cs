﻿namespace GatewayService.Models;

public class UserClaims
{
    public int UserId { get; set; }
    public string Email { get; set; }
    public string Name { get; set; }
}
