namespace CrypticAnalytic.Enums;

public enum CurrencyType : int
{
    USD = 1,
    BTC = 2,
    ETH = 3,
    SOL = 4
}