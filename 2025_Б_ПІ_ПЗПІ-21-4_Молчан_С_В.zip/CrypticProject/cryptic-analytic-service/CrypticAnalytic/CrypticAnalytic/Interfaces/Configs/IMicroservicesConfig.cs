namespace CrypticAnalytic.Interfaces.Configs;

public interface IMicroservicesConfig
{
    public string BlockchainInteractionConnString { get; }
}