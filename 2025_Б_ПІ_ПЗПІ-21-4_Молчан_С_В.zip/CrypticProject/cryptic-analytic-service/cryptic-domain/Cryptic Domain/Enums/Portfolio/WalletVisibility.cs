namespace Cryptic_Domain.Enums.Portfolio;

public enum WalletVisibility
{
    Private = 0,
    Public = 1
}