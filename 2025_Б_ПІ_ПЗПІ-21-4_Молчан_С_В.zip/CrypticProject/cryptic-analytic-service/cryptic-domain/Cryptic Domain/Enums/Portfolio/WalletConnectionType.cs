namespace Cryptic_Domain.Enums.Portfolio;

public enum WalletConnectionType
{
    Manual = 0,
    Auto = 1
}