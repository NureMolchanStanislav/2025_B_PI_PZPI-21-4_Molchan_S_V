namespace Cryptic_Domain.Interfaces.Database;

public interface IDatabaseView : IDatabaseTable
{
    
}