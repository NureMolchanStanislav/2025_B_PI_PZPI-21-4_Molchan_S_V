namespace Cryptic_Domain.Interfaces.Database;

public interface IDatabaseTable
{
    
}