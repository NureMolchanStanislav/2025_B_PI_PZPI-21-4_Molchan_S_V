﻿using System.Diagnostics;

const int TokensPerBatch = 10000;
        // Скільки батчів надіслати
        const int BatchCount = 10;

        static async Task Main(string[] args)
        {
            // Конфігуруємо MassTransit
            var bus = Bus.Factory.CreateUsingRabbitMq(cfg =>
            {
                cfg.Host("rabbitmq://10.0.0.4:1337/", h =>
                {
                    h.Username("dev");
                    h.Password("ncA66MBWbwnmjakEuT6GBU4L");
                    h.VirtualHost("/");
                });
            });
            await bus.StartAsync();
            Console.WriteLine("Bus started.");

            var rnd = new Random();
            var sw = Stopwatch.StartNew();

            for (int batch = 0; batch < BatchCount; batch++)
            {
                // Генеруємо словник токен→GUID
                var dict = new Dictionary<string, Guid>(TokensPerBatch);
                for (int i = 0; i < TokensPerBatch; i++)
                {
                    // генеруємо «токен» — 152 символи Base64 (як приклад)
                    var tokenBytes = new byte[114]; // ~152 chars base64
                    rnd.NextBytes(tokenBytes);
                    string fakeFcmToken = Convert.ToBase64String(tokenBytes);

                    // генеруємо GUID
                    dict[fakeFcmToken] = Guid.NewGuid();
                }

                var notifMsg = new NotificationMessage
                {
                    Title = "LoadTest",
                    Body  = "Performance test",
                    Tokens = dict,
                    Image = null,
                    Icon  = null
                };

                var model = new SendNotificationFcm(new NotificationModel
                {
                    NotificationMessage = notifMsg,
                    AppId = 330,
                    ApplicationType = ApplicationType.Android,
                    AppFcmId = "1:1234567890:android:abcdef",
                    TrackingId = Guid.NewGuid().ToString(),
                    SubTaskId = 0
                });
                
                await bus.Publish(model);
                Console.WriteLine($"Batch {batch+1}/{BatchCount} sent ({TokensPerBatch} tokens).");
            }

            sw.Stop();
            Console.WriteLine($"All done in {sw.Elapsed.TotalSeconds:F2}s");

            Console.WriteLine("Press any key to exit...");
            Console.ReadKey();

            await bus.StopAsync();
        }